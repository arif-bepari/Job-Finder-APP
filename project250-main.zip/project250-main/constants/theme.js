const COLORS = {
  primary: "#0e3367ff",
  secondary: "#0b3b84ff",
  tertiary: "#a62f2fff",

  background: "#a9c2e7ff",
  cardBackground: "#e2563dff",
  white: "#acdbecff",
  lightWhite: "#91bee1ff",

  gray: "#374a60ff",
  gray2: "#36383bff",
  darkGray: "#6a8cc2ff",

  success: "#0b5e29ff",
  warning: "#b39315ff",
  error: "#ab3232ff",
};

const FONT = {
  regular: "DMRegular",
  medium: "DMMedium",
  bold: "DMBold",
  semiBold: "DMSemiBold",
};

const SIZES = {
  xSmall: 10,
  small: 12,
  medium: 16,
  large: 20,
  xLarge: 24,
  xxLarge: 32,
  title: 40,
};

const SHADOWS = {
  small: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  medium: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
};

export { COLORS, FONT, SIZES, SHADOWS };
