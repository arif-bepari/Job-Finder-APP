import profile from "../assets/images/kemal.jpeg";
import jobe from "../assets/images/jobe.jpg";
export default {
  jobe,
  profile,
  
};
