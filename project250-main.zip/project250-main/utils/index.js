export const checkImageURL = (url) => {
  if (!url || typeof url !== 'string') return false;

  const trimmedUrl = url.trim();

  const pattern = /^https?:\/\/.+\.(png|jpg|jpeg|bmp|gif|webp)$/i;

  return pattern.test(trimmedUrl);
};
