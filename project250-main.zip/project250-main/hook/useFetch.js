import { useState, useEffect } from 'react';
import axios from 'axios';

const useFetch = (endpoint, query) => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.request({
        method: 'GET',
        url: `https://jsearch.p.rapidapi.com/${endpoint}`,
        headers: {
          'x-rapidapi-key': '4f59238c8amshbd134c447e4a22ep139c0fjsn90d2ff29a04e',
          'x-rapidapi-host': 'jsearch.p.rapidapi.com',
        },
        params: {
          ...query,
        },
      });

      setData(response.data.data);
    } catch (err) {
      setError(err);
      console.error('Fetch error:', err);
      // Removed alert for smoother UX
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [endpoint, JSON.stringify(query)]);

  const refetch = () => {
    fetchData();
  };

  return { data, isLoading, error, refetch };
};

export default useFetch;

